# enum ServiceVersion

## Overview / Purpose

Enumeration ServiceVersion

|Enumerator|Value|Description|
|----------|-----|-----------|
|RESERVED\_0|0|Reserved|
|CURRENT\_VERSION|1|Current version|

**Parent topic:** [VisionConfig \(C++\)](../../summary_pages/VisionConfig.md)

