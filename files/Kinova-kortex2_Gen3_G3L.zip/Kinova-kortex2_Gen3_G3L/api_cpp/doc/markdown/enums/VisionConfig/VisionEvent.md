# enum VisionEvent

## Overview / Purpose

Enumeration VisionEvent

|Enumerator|Value|Description|
|----------|-----|-----------|
|UNSPECIFIED\_VISION\_EVENT|0|Unspecified vision event|
|SENSOR\_SETTINGS\_CHANGED|1|Sensor setting changed event|
|OPTION\_VALUE\_CHANGED|2|Option value changed event|

**Parent topic:** [VisionConfig \(C++\)](../../summary_pages/VisionConfig.md)

