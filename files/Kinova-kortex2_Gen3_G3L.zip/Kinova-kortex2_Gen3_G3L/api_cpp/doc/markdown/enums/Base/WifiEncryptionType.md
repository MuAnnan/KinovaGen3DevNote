# enum WifiEncryptionType

## Overview / Purpose

Enumeration WifiEncryptionType

|Enumerator|Value|Description|
|----------|-----|-----------|
|UNSPECIFIED\_ENCRYPTION|0|Unspecified Wi-Fi encryption type|
|AES\_ENCRYPTION|1|AES encryption|
|TKIP\_ENCRYPTION|2|TKIP encryption|
|WEP\_ENCRYPTION|4|WEP encryption|

**Parent topic:** [Base \(C++\)](../../summary_pages/Base.md)

