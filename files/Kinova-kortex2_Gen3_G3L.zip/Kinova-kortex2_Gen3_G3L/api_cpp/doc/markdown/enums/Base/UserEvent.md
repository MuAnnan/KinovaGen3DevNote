# enum UserEvent

## Overview / Purpose

Enumeration UserEvent

|Enumerator|Value|Description|
|----------|-----|-----------|
|UNSPECIFIED\_USER\_EVENT|0|Unspecified user event|
|LOGGED\_OUT|1|User logged out|
|LOGGED\_IN|2|User logged in|

**Parent topic:** [Base \(C++\)](../../summary_pages/Base.md)

