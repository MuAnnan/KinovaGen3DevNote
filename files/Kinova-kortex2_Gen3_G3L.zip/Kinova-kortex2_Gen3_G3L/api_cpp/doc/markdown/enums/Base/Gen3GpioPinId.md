# enum Gen3GpioPinId

## Overview / Purpose

Enumeration Gen3GpioPinId

|Enumerator|Value|Description|
|----------|-----|-----------|
|UNSPECIFIED\_PIN|0|Unspecified PIN ID|
|GPIO\_PIN\_B|1|GPIO PIN B|
|GPIO\_PIN\_C|2|GPIO PIN C|
|GPIO\_PIN\_D|3|GPIO PIN D|
|GPIO\_PIN\_E|4|GPIO PIN E|
|GPIO\_PIN\_G|5|GPIO PIN G|
|GPIO\_PIN\_H|6|GPIO PIN H|
|GPIO\_PIN\_I|7|GPIO PIN I|
|GPIO\_PIN\_K|8|GPIO PIN K|
|GPIO\_PIN\_N|9|GPIO PIN N|
|GPIO\_PIN\_O|10|GPIO PIN O|
|GPIO\_PIN\_S|11|GPIO PIN S|
|GPIO\_PIN\_T|12|GPIO PIN T|

**Parent topic:** [Base \(C++\)](../../summary_pages/Base.md)

