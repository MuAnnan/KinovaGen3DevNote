# enum WristType

## Overview / Purpose

Enumeration WristType

|Enumerator|Value|Description|
|----------|-----|-----------|
|WRIST\_TYPE\_UNSPECIFIED|0|Unspecified wrist type|
|WRIST\_TYPE\_NOT\_APPLICABLE|1|Not Applicable|
|WRIST\_TYPE\_SPHERICAL|2|Spherical Wrist|
|WRIST\_TYPE\_CURVED|3|Curved Wrist|

**Parent topic:** [ProductConfiguration \(C++\)](../../summary_pages/ProductConfiguration.md)

