# enum ArmLaterality

## Overview / Purpose

Enumeration ArmLaterality

|Enumerator|Value|Description|
|----------|-----|-----------|
|ARM\_LATERALITY\_UNSPECIFIED|0|Unspecified arm laterality|
|ARM\_LATERALITY\_NOT\_APPLICABLE|1|Not Applicable|
|ARM\_LATERALITY\_LEFT|2|Left Laterality|
|ARM\_LATERALITY\_RIGHT|3|Right Laterality|

**Parent topic:** [ProductConfiguration \(C++\)](../../summary_pages/ProductConfiguration.md)

