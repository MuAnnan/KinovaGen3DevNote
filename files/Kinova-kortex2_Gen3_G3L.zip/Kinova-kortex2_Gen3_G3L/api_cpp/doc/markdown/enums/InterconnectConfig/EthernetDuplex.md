# enum EthernetDuplex

## Overview / Purpose

Enumeration EthernetDuplex

|Enumerator|Value|Description|
|----------|-----|-----------|
|ETHERNET\_DUPLEX\_UNSPECIFIED|0|Unspecified ethernet duplex|
|ETHERNET\_DUPLEX\_HALF|1|Half duplex|
|ETHERNET\_DUPLEX\_FULL|2|Full duplex|

**Parent topic:** [InterconnectConfig \(C++\)](../../summary_pages/InterconnectConfig.md)

