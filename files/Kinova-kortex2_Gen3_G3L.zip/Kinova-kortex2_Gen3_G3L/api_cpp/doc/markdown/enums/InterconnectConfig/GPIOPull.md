# enum GPIOPull

## Overview / Purpose

Enumeration GPIOPull

|Enumerator|Value|Description|
|----------|-----|-----------|
|GPIO\_PULL\_UNSPECIFIED|0|Unspecified GPIO pull|
|GPIO\_PULL\_NONE|1|Pull none|
|GPIO\_PULL\_UP|2|Pull up|
|GPIO\_PULL\_DOWN|3|Pull down|

**Parent topic:** [InterconnectConfig \(C++\)](../../summary_pages/InterconnectConfig.md)

