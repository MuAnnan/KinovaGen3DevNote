# enum EthernetSpeed

## Overview / Purpose

Enumeration EthernetSpeed

|Enumerator|Value|Description|
|----------|-----|-----------|
|ETHERNET\_SPEED\_UNSPECIFIED|0|Unspecified ethernet speed|
|ETHERNET\_SPEED\_10M|1|10 Mbps|
|ETHERNET\_SPEED\_100M|2|100 Mbps|

**Parent topic:** [InterconnectConfig \(C++\)](../../summary_pages/InterconnectConfig.md)

