# class EmergencyStop

**Parent topic:** [Base \(C++\)](../../summary_pages/Base.md)

