The 2F-85 gripper depends on the package maintained by [PickNik Robotics](https://github.com/PickNikRobotics/ros2_robotiq_gripper).
The package's license file can also be found in this folder.
