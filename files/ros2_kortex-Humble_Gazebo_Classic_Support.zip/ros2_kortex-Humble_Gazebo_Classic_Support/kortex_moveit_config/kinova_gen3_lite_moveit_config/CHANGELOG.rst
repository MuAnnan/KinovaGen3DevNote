^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package kinova_gen3_lite_moveit_config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.3 (2025-02-27)
------------------
* Fixed the Gazebo Fortress Simulation + Separated the arm and gripper control for Gen3_Lite + Fixed bugs (`#252 <https://github.com/Kinovarobotics/ros2_kortex/issues/252>`_)
  * Modified the Gen3_Lite Moveit Package for arm-gripper control separation
* Added a Moveit2 package for Gen3-Lite (`#231 <https://github.com/Kinovarobotics/ros2_kortex/issues/231>`_)
* Contributors: aalmrad

0.2.2 (2023-08-09)
------------------

0.2.1 (2023-07-26)
------------------

0.2.0 (2023-07-17)
------------------

0.1.0 (2021-09-12)
------------------
